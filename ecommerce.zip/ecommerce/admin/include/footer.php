 <footer class="footer" style="text-align: center;">Copyright © 2024 - Farmers' Ecommerce Shop <a href="about.html">by Group #</a> </footer>
<!-- about.html for the group-->